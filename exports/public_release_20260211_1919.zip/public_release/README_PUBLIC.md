# Cohort Retention Decision Pack (DTC / eCommerce)

This repository publishes a public-safe export only.
Full pipeline + governance checks available on request.

## Business Question
Which first-order product families are underperforming on early retention, and what should be tested in the next two weeks to improve M2 outcomes without harming margin quality?

## What Was Delivered
- `public_release/exports/cohort_retention_story.html` with a 3-chart narrative.
- `public_release/docs/DECISION_MEMO_1PAGE.md` with target families and decision framing.
- `public_release/case_study_readme.md` with a week-by-week RevOps roadmap.
- `public_demo/demo_output.png` and `public_demo/demo_summary.csv` as a runnable demo slice.

## What We Found (Directional, Not Causal)
- Lowest M2 retention families: `Seasonal`, `Home_Fragrance`, `Bags`.
- Chart 2 net-retention curves provide expected value-retention trajectories for calibration.
- Recommended action: prioritize experiments in those three families first.

## Key Definitions (High-Level)
- Net retention proxy: monthly net value proxy divided by cohort month-0 gross baseline.
- Right-censoring policy: unobserved late months are shown as missing (not zero).
- Horizon: `H=6` months from first purchase (months `0..6`).

## Next 2 Weeks
- Week 1: define hypotheses and test slate by target family, with thresholds and guardrails.
- Week 2: launch controlled tests, run first readout, and decide to scale/pause.

## Success Thresholds + Guardrails
- Target M2 logo retention lift: `+X pp` vs control.
- Target M2 net proxy retention lift: `+Y pp`.
- Improve net-minus-logo gap toward `>= 0 pp` in at least 2 of 3 target families.
- Guardrails: margin proxy not worse than `-Z%`, stable cohort quality, no adverse credit-like-rate shift.
